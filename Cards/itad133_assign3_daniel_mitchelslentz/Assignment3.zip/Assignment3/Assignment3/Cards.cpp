
#include <iostream>

using namespace std;
#include "Deck.h"
#include "Hand.h"

int main(int argc, char *argv[]) {


	Deck theDeck;

	cout << "..." << endl;
	cout << theDeck << "..." << endl;
	theDeck.Shuffle();
	cout << theDeck << "..." << endl;

	Hand hand[4];

	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			hand[j].Dealt(theDeck.Deal());
		}
	}

	for (int i = 0; i < 4; i++)
	{
		cout << "hand " << i << ": " << hand[i] << endl;
	}

	cout << endl << "Number of playing cards at this time: " << PlayingCard::getCardCounter() << endl;//this is to keep track of the number of playing cards constructed I also count them down as they are destroyed

	return 0;
}

