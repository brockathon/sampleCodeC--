#include <iostream>
#include <ostream>
using namespace std;
#include "Hand.h"

Hand::Hand()
{
	// location in the card array where the next 
	// dynamically allocated (dealt) card will go
	nextCard = 0;
}

Hand::~Hand() 
{ }

void Hand::Dealt(PlayingCard *newCard)
{
	if (nextCard >= FiveCardDrawCt)
	{
		exit(-1);
	}
	handCards[nextCard++] = newCard;
}

ostream& operator<<(ostream &os, const Hand& hand)
{
	// todo: output the cards in a hand
	for (int i = 0; i < hand.nextCard; ++i)
	{
		os << *hand.handCards[i] << " ";
	}
	return os;
}